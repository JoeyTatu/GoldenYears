<?php

DEFINE ('DB_USER', 'username');
DEFINE ('DB_PSWD', 'password');
DEFINE ('DB_HOST', 'db1.webdev89.cocc-webdev.org');
DEFINE ('DB_NAME', 'login.html');

?>